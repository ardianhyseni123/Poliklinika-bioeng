import 'dotenv/config';
import bcrypt from 'bcrypt';
import { Pool } from 'pg';
import { randomUUID } from 'crypto';

const [email, password, role, fullName, title] = process.argv.slice(2);
if (!email || !password || !role || !fullName || !title) {
  console.error('Përdorimi: node src/create-user.js email fjalekalimi ROLI "Emër Mbiemër" "Titulli"'); process.exit(1);
}
const allowed=['LABORATOR','KARDIOLOGJI','PULMOLOGJI','NEUROLOGJI','HIXHAME','ADMIN'];
if(!allowed.includes(role)) { console.error('Roli nuk është i vlefshëm.'); process.exit(1); }
const pool=new Pool({connectionString:process.env.DATABASE_URL});
const hash=await bcrypt.hash(password,12);
await pool.query('INSERT INTO users(id,email,password_hash,role,full_name,professional_title) VALUES($1,$2,$3,$4,$5,$6)',[randomUUID(),email.toLowerCase(),hash,role,fullName,title]);
await pool.end(); console.log('Përdoruesi u krijua.');
