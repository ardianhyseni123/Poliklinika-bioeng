import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { Pool } from 'pg';
import { randomUUID } from 'crypto';
import { z } from 'zod';

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const port = Number(process.env.PORT || 3000);
const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) throw new Error('JWT_SECRET duhet të ketë të paktën 32 karaktere.');

app.use(helmet());
app.use(express.json({ limit: '2mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false }));

function tokenFor(user) { return jwt.sign({ sub: user.id, role: user.role, name: user.full_name }, secret, { expiresIn: '8h' }); }
function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, secret); next(); } catch { res.status(401).json({ error: 'Kërkohet hyrje e vlefshme.' }); }
}
function allow(...roles) { return (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'Nuk keni qasje në këtë veprim.' }); }

app.get('/health', async (_req, res) => { await pool.query('SELECT 1'); res.json({ status: 'ok' }); });

app.post('/api/auth/login', async (req, res) => {
  const body = z.object({ email: z.string().email(), password: z.string().min(8) }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: 'Të dhënat e hyrjes nuk janë të vlefshme.' });
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1 AND active=true', [body.data.email.toLowerCase()]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(body.data.password, user.password_hash))) return res.status(401).json({ error: 'Emaili ose fjalëkalimi është i pasaktë.' });
  res.json({ token: tokenFor(user), user: { id: user.id, role: user.role, name: user.full_name, title: user.professional_title } });
});

app.get('/api/patients', authenticate, async (_req, res) => {
  const { rows } = await pool.query('SELECT * FROM patients ORDER BY last_name, first_name'); res.json(rows);
});
app.post('/api/patients', authenticate, async (req, res) => {
  const body = z.object({ firstName:z.string().min(1), lastName:z.string().min(1), birthDate:z.string().optional(), gender:z.string().optional(), phone:z.string().optional(), address:z.string().optional() }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error:'Të dhënat e pacientit nuk janë të vlefshme.' });
  const p = body.data, id = randomUUID();
  const { rows } = await pool.query('INSERT INTO patients(id,first_name,last_name,birth_date,gender,phone,address) VALUES($1,$2,$3,NULLIF($4,\'\')::date,$5,$6,$7) RETURNING *',[id,p.firstName,p.lastName,p.birthDate||'',p.gender||'',p.phone||'',p.address||'']);
  res.status(201).json(rows[0]);
});

app.get('/api/patients/:patientId/reports', authenticate, async (req, res) => {
  const params=[req.params.patientId]; let where='patient_id=$1';
  if (!['ADMIN','LABORATOR'].includes(req.user.role)) { params.push(req.user.role); where+=' AND specialty=$2'; }
  const { rows } = await pool.query(`SELECT * FROM reports WHERE ${where} ORDER BY report_at DESC`, params); res.json(rows);
});
app.post('/api/reports', authenticate, async (req, res) => {
  const body=z.object({ patientId:z.string().uuid(), reportAt:z.string(), reportType:z.enum(['LABORATORY','SPECIALIST']), specialty:z.string(), payload:z.record(z.string(),z.unknown()) }).safeParse(req.body);
  if(!body.success) return res.status(400).json({ error:'Raporti nuk është i vlefshëm.' });
  const r=body.data; const specialist=!['ADMIN','LABORATOR'].includes(req.user.role);
  if(specialist && (r.reportType!=='SPECIALIST' || r.specialty!==req.user.role)) return res.status(403).json({ error:'Raporti duhet t’i përkasë specialitetit tuaj.' });
  const id=randomUUID(); await pool.query('INSERT INTO reports(id,patient_id,specialty,report_type,author_id,report_at,payload) VALUES($1,$2,$3,$4,$5,$6,$7)',[id,r.patientId,r.specialty,r.reportType,req.user.sub,r.reportAt,r.payload]);
  await pool.query('INSERT INTO audit_log(id,actor_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4,$5)',[randomUUID(),req.user.sub,'CREATE','REPORT',id]);
  res.status(201).json({ id });
});

app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error:'Gabim i brendshëm i serverit.' }); });
app.listen(port, () => console.log(`Bioeng server running on port ${port}`));
