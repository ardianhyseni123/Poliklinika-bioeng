# Bioeng — serveri qendror

Ky server ruan pacientët dhe raportet në PostgreSQL. Nuk ruan fjalëkalime në tekst të hapur.

## Mos bëni ende

- Mos e hapni portin `3000` në internet.
- Mos dërgoni këtu çelësat privatë të WireGuard ose fjalëkalimet e routerit.
- Mos instaloni konfigurime WireGuard të njëjta në pajisje të ndryshme.

## Instalimi në kompjuterin-server të klinikës

1. Instaloni Node.js LTS dhe PostgreSQL.
2. Krijoni databazën `bioeng_clinic` dhe përdoruesin `bioeng_app` me fjalëkalim të fortë.
3. Ekzekutoni `sql/schema.sql` në PostgreSQL.
4. Kopjoni `.env.example` si `.env`, pastaj vendosni fjalëkalimin e databazës dhe një `JWT_SECRET` të gjatë e unik.
5. Në këtë dosje, hapni PowerShell dhe ekzekutoni:

   `npm install`

   `npm start`

6. Krijoni përdoruesit individualë, p.sh.:

   `node src/create-user.js kardiolog@bioeng.com FJALEKALIMI_I_RI KARDIOLOGJI "Dr. Rilind Sylaj" "Specialist i Kardiologjisë"`

Për laborator, rol përdorni `LABORATOR`; për pulmologji `PULMOLOGJI`; neurologji `NEUROLOGJI`; dhe Hixhame `HIXHAME`.

## WireGuard

WireGuard vendoset në kompjuterin-server dhe në çdo pajisje të autorizuar. Çdo pajisje merr profil/çelës të veçantë. Aplikacioni do të hapet vetëm mbi adresën VPN të serverit, jo mbi port të hapur publik.

Para konfigurimit të klientëve, duhet të kemi modelin e routerit, IP-në lokale të kompjuterit-server dhe të verifikojmë nëse interneti i klinikës ka IP publike / lejon port-forwarding.
